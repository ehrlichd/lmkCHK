# lmkCHK
Helper functions for visualizing and screening 2D/3D landmark data.

WIP.

