# lmkCHK
An R package to visualize and screen 3D landmark data

lmkCHK complements other morphometric packages (geomorph, Morpho, shapes) by providing additional functionality for visualizing large arrays of landmark data in 3D space. Includes interactive functions to screen for outliers, and asssess inter-/intra- observer error using a variety of metrics. 
